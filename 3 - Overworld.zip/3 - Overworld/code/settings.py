screen_width = 1280
screen_height = 720